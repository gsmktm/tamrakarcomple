"use client";

import ShareButtons from "@/components/ShareButtons";

interface ShareButtonsWrapperProps {
  url: string;
  title: string;
}

export default function ShareButtonsWrapper({ url, title }: ShareButtonsWrapperProps) {
  return <ShareButtons url={url} title={title} />;
}
