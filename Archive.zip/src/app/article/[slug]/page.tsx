import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import ReviewCard from "@/components/ReviewCard";
import ShareButtonsWrapper from "@/components/ShareButtonsWrapper";

interface ArticlePageProps {
  params: { slug: string };
}

async function getPost(slug: string) {
  const post = await prisma.post.findUnique({
    where: { slug, status: 'PUBLISHED' },
    include: {
      category: true,
      author: { 
        include: { user: { select: { name: true } } }
      },
      tags: { include: { tag: true } },
      review: true,
    },
  });
  return post;
}

async function getCategories() {
  const categories = await prisma.category.findMany({
    orderBy: { name: "asc" },
  });
  return categories;
}

export default async function ArticlePage({ params }: ArticlePageProps) {
  const [post, categories] = await Promise.all([
    getPost(params.slug),
    getCategories(),
  ]);

  if (!post) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="text-2xl font-bold text-primary-600">
              Tamrakar Complex
            </Link>
            <nav className="hidden md:flex space-x-8">
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/category/${cat.slug}`}
                  className="text-gray-600 hover:text-primary-600 font-medium"
                >
                  {cat.name}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Article Content */}
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border p-8">
              <div className="mb-6">
                <Link
                  href={`/category/${post.category.slug}`}
                  className="text-primary-600 font-medium hover:underline"
                >
                  {post.category.name}
                </Link>
              </div>

              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {post.title}
              </h1>

              <div className="flex items-center text-sm text-gray-500 mb-8">
                <span>By {post.author.user.name}</span>
                <span className="mx-2">•</span>
                <span>
                  {post.publishedAt
                    ? new Date(post.publishedAt).toLocaleDateString()
                    : ""}
                </span>
              </div>

              {post.heroImage && (
                <img
                  src={post.heroImage}
                  alt={post.title}
                  className="w-full h-64 md:h-96 object-cover rounded-lg mb-8"
                />
              )}

              <div
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: post.content }}
              />

              <div className="mt-8 pt-8 border-t">
                <div className="flex flex-wrap gap-2">
                  {post.tags.map(({ tag }) => (
                    <span
                      key={tag.id}
                      className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm"
                    >
                      {tag.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            {post.review && (
              <ReviewCard
                rating={post.review.rating}
                pros={post.review.pros || undefined}
                cons={post.review.cons || undefined}
                verdict={post.review.verdict || undefined}
              />
            )}
            
            <ShareButtonsWrapper 
              url={`/article/${post.slug}`}
              title={post.title}
            />
          </aside>
        </div>
      </article>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-bold">Tamrakar Complex</h3>
              <p className="text-gray-400 mt-1">
                © {new Date().getFullYear()} All rights reserved
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
