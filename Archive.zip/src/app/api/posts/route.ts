import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const posts = await prisma.post.findMany({
      where: { status: 'PUBLISHED' },
      orderBy: { createdAt: 'desc' },
      include: {
        category: true,
        author: { 
          include: { user: { select: { name: true } } }
        },
        tags: { include: { tag: true } },
      },
    })

    return NextResponse.json({ posts })
  } catch (error) {
    console.error('Error fetching posts:', error)
    return NextResponse.json(
      { error: 'Failed to fetch posts' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    const post = await prisma.post.create({
      data: {
        title: data.title,
        slug: data.slug,
        excerpt: data.excerpt,
        content: data.content,
        heroImage: data.featuredImage,
        status: data.published ? 'PUBLISHED' : 'DRAFT',
        publishedAt: data.published ? new Date() : null,
        authorId: data.authorId,
        categoryId: data.categoryId,
      },
    })

    // Handle tags
    if (data.tagIds && data.tagIds.length > 0) {
      await prisma.postTag.createMany({
        data: data.tagIds.map((tagId: string) => ({
          postId: post.id,
          tagId,
        })),
      })
    }

    return NextResponse.json({ post })
  } catch (error) {
    console.error('Error creating post:', error)
    return NextResponse.json(
      { error: 'Failed to create post' },
      { status: 500 }
    )
  }
}
