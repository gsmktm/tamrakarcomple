import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const posts = await prisma.post.findMany({
      where: { 
        status: 'PUBLISHED',
        type: 'GUIDE'
      },
      orderBy: { publishedAt: 'desc' },
      take: 20,
      include: {
        category: true,
        author: { 
          include: { user: { select: { name: true } } }
        },
        tags: { include: { tag: true } },
      },
    })

    return NextResponse.json({ posts })
  } catch (error) {
    console.error('Error fetching guides:', error)
    return NextResponse.json(
      { error: 'Failed to fetch guides' },
      { status: 500 }
    )
  }
}
