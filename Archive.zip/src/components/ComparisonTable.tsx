"use client";

interface ComparisonTableProps {
  products: {
    name: string;
    price?: string;
    rating?: number;
    specs: { [key: string]: string };
    pros?: string[];
    cons?: string[];
  }[];
}

export default function ComparisonTable({ products }: ComparisonTableProps) {
  if (products.length === 0) return null;

  // Get all unique spec keys from all products
  const allSpecKeys = Array.from(
    new Set(products.flatMap(product => Object.keys(product.specs)))
  );

  return (
    <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
      <div className="p-6 border-b">
        <h3 className="text-lg font-semibold text-gray-900">Product Comparison</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Feature
              </th>
              {products.map((product, index) => (
                <th key={index} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  {product.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {/* Price row */}
            <tr>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Price
              </td>
              {products.map((product, index) => (
                <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {product.price || '-'}
                </td>
              ))}
            </tr>

            {/* Rating row */}
            <tr className="bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Rating
              </td>
              {products.map((product, index) => (
                <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {product.rating ? (
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-400">★</span>
                      <span>{product.rating}/5</span>
                    </div>
                  ) : (
                    '-'
                  )}
                </td>
              ))}
            </tr>

            {/* Specs rows */}
            {allSpecKeys.map(specKey => (
              <tr key={specKey}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {specKey}
                </td>
                {products.map((product, index) => (
                  <td key={index} className="px-6 py-4 text-sm text-gray-900">
                    {product.specs[specKey] || '-'}
                  </td>
                ))}
              </tr>
            ))}

            {/* Pros row */}
            {(products.some(p => p.pros && p.pros.length > 0)) && (
              <tr className="bg-gray-50">
                <td className="px-6 py-4 text-sm font-medium text-gray-900">
                  <div className="flex items-center gap-1">
                    <span className="text-green-600">✓</span>
                    <span>Pros</span>
                  </div>
                </td>
                {products.map((product, index) => (
                  <td key={index} className="px-6 py-4 text-sm text-gray-900">
                    {product.pros && product.pros.length > 0 ? (
                      <ul className="space-y-1">
                        {product.pros.slice(0, 3).map((pro, proIndex) => (
                          <li key={proIndex} className="text-green-600">
                            • {pro}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      '-'
                    )}
                  </td>
                ))}
              </tr>
            )}

            {/* Cons row */}
            {(products.some(p => p.cons && p.cons.length > 0)) && (
              <tr>
                <td className="px-6 py-4 text-sm font-medium text-gray-900">
                  <div className="flex items-center gap-1">
                    <span className="text-red-600">✗</span>
                    <span>Cons</span>
                  </div>
                </td>
                {products.map((product, index) => (
                  <td key={index} className="px-6 py-4 text-sm text-gray-900">
                    {product.cons && product.cons.length > 0 ? (
                      <ul className="space-y-1">
                        {product.cons.slice(0, 3).map((con, conIndex) => (
                          <li key={conIndex} className="text-red-600">
                            • {con}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      '-'
                    )}
                  </td>
                ))}
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
