"use client";

interface ShareButtonsProps {
  url: string;
  title: string;
}

export default function ShareButtons({ url, title }: ShareButtonsProps) {
  const shareLinks = [
    {
      name: "Facebook",
      icon: "📘",
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
    },
    {
      name: "Twitter",
      icon: "🐦",
      url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`,
    },
    {
      name: "LinkedIn",
      icon: "💼",
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
    },
    {
      name: "WhatsApp",
      icon: "📱",
      url: `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`,
    },
    {
      name: "Copy Link",
      icon: "🔗",
      action: () => {
        navigator.clipboard.writeText(url);
        alert("Link copied to clipboard!");
      },
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <h3 className="font-semibold text-gray-900 mb-4">Share this article</h3>
      <div className="flex flex-wrap gap-3">
        {shareLinks.map((link, index) => (
          <button
            key={index}
            onClick={() => {
              if (link.action) {
                link.action();
              } else {
                window.open(link.url, "_blank", "width=600,height=400");
              }
            }}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors text-sm font-medium"
          >
            <span>{link.icon}</span>
            <span>{link.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
