import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(request: Request) {
  try {
    const { email } = await request.json()

    if (!email || !email.includes('@')) {
      return NextResponse.json(
        { error: 'Valid email is required' },
        { status: 400 }
      )
    }

    // Store in database (you could also use a service like Mailchimp)
    const existing = await prisma.siteSetting.findUnique({
      where: { key: 'newsletter_subscribers' }
    })

    const subscribers = existing ? JSON.parse(existing.value) : []
    
    if (subscribers.includes(email)) {
      return NextResponse.json(
        { message: 'Already subscribed' },
        { status: 200 }
      )
    }

    subscribers.push(email)
    
    await prisma.siteSetting.upsert({
      where: { key: 'newsletter_subscribers' },
      update: { value: JSON.stringify(subscribers) },
      create: {
        key: 'newsletter_subscribers',
        value: JSON.stringify(subscribers),
        description: 'Newsletter subscriber emails'
      }
    })

    return NextResponse.json({ message: 'Successfully subscribed!' })
  } catch (error) {
    console.error('Newsletter signup error:', error)
    return NextResponse.json(
      { error: 'Failed to subscribe' },
      { status: 500 }
    )
  }
}
