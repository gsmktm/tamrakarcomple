"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface NewsPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  publishedAt: string;
  category: { name: string; slug: string };
  author: { user: { name: string } };
  tags: { tag: { name: string } }[];
}

export default function NewsPage() {
  const [posts, setPosts] = useState<NewsPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  async function fetchPosts() {
    try {
      const res = await fetch("/api/news");
      const data = await res.json();
      setPosts(data.posts || []);
    } catch (error) {
      console.error("Error fetching news:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="text-2xl font-bold text-primary-600">
              Tamrakar Complex
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/news" className="text-primary-600 font-medium">
                News
              </Link>
              <Link href="/reviews" className="text-gray-600 hover:text-primary-600 font-medium">
                Reviews
              </Link>
              <Link href="/guides" className="text-gray-600 hover:text-primary-600 font-medium">
                Guides
              </Link>
              <Link href="/search" className="text-gray-600 hover:text-primary-600 font-medium">
                Search
              </Link>
            </nav>
            <Link href="/" className="text-gray-600 hover:text-gray-900">
              ← Home
            </Link>
          </div>
        </div>
      </header>

      {/* Page Header */}
      <section className="bg-primary-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold">Latest News</h1>
          <p className="mt-2 text-primary-100 text-lg">
            Stay updated with the latest technology news and updates
          </p>
        </div>
      </section>

      {/* News List */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                  <span className="text-primary-600 font-medium">
                    {post.category.name}
                  </span>
                  <span>•</span>
                  <span>
                    {post.publishedAt
                      ? new Date(post.publishedAt).toLocaleDateString()
                      : ""}
                  </span>
                </div>
                <Link href={`/article/${post.slug}`}>
                  <h2 className="text-xl font-bold text-gray-900 hover:text-primary-600 mb-2 transition-colors">
                    {post.title}
                  </h2>
                </Link>
                <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">
                    By {post.author.user.name}
                  </span>
                  <div className="flex gap-2">
                    {post.tags.slice(0, 2).map(({ tag }) => (
                      <span
                        key={tag.name}
                        className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full"
                      >
                        {tag.name}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>

        {posts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No news articles found.</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-bold">Tamrakar Complex</h3>
              <p className="text-gray-400 mt-1">
                © {new Date().getFullYear()} All rights reserved
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
