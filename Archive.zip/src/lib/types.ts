export const POST_TYPES = {
  NEWS: 'NEWS',
  REVIEW: 'REVIEW', 
  GUIDE: 'GUIDE',
  EDITORIAL: 'EDITORIAL'
} as const;

export const POST_STATUS = {
  DRAFT: 'DRAFT',
  PUBLISHED: 'PUBLISHED',
  SCHEDULED: 'SCHEDULED'
} as const;

export type PostType = typeof POST_TYPES[keyof typeof POST_TYPES];
export type PostStatus = typeof POST_STATUS[keyof typeof POST_STATUS];
