"use client";

interface ReviewCardProps {
  rating: number;
  pros?: string;
  cons?: string;
  verdict?: string;
}

export default function ReviewCard({ rating, pros, cons, verdict }: ReviewCardProps) {
  return (
    <div className="bg-gradient-to-br from-primary-50 to-white rounded-lg border border-primary-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Our Review</h3>
        <div className="text-2xl font-bold text-primary-600">{rating}/5</div>
      </div>
      
      <div className="mb-4">
        <div className="flex items-center gap-1 text-yellow-400 text-lg">
          {[...Array(5)].map((_, index) => (
            <span key={index} className={index < rating ? 'text-yellow-400' : 'text-gray-300'}>
              ★
            </span>
          ))}
        </div>
      </div>

      {pros && (
        <div className="mb-4">
          <h4 className="font-medium text-green-700 mb-2">✓ Pros</h4>
          <div 
            className="text-gray-700 text-sm"
            dangerouslySetInnerHTML={{ __html: pros.replace(/\n/g, '<br>') }}
          />
        </div>
      )}

      {cons && (
        <div className="mb-4">
          <h4 className="font-medium text-red-700 mb-2">✗ Cons</h4>
          <div 
            className="text-gray-700 text-sm"
            dangerouslySetInnerHTML={{ __html: cons.replace(/\n/g, '<br>') }}
          />
        </div>
      )}

      {verdict && (
        <div className="border-t pt-4">
          <h4 className="font-medium text-gray-900 mb-2">Verdict</h4>
          <p className="text-gray-700 text-sm italic">{verdict}</p>
        </div>
      )}
    </div>
  );
}
