import Link from "next/link";
import { prisma } from "@/lib/prisma";
import NewsletterSignup from "@/components/NewsletterSignup";

async function getPosts() {
  const posts = await prisma.post.findMany({
    where: { status: 'PUBLISHED' },
    orderBy: { publishedAt: "desc" },
    take: 10,
    include: {
      category: true,
      author: { 
        include: { user: { select: { name: true } } }
      },
      tags: { include: { tag: true } },
    },
  });
  return posts;
}

async function getCategories() {
  const categories = await prisma.category.findMany({
    orderBy: { name: "asc" },
  });
  return categories;
}

export default async function Home() {
  const [posts, categories] = await Promise.all([getPosts(), getCategories()]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="text-2xl font-bold text-primary-600">
              Tamrakar Complex
            </Link>
            <nav className="hidden md:flex space-x-8">
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/category/${cat.slug}`}
                  className="text-gray-600 hover:text-primary-600 font-medium"
                >
                  {cat.name}
                </Link>
              ))}
              <Link
                href="/search"
                className="text-gray-600 hover:text-primary-600 font-medium"
              >
                Search
              </Link>
            </nav>
            <div className="flex items-center gap-4">
              <Link
                href="/search"
                className="md:hidden text-gray-600 hover:text-primary-600"
              >
                🔍
              </Link>
              <Link
                href="/admin"
                className="text-sm text-gray-500 hover:text-primary-600"
              >
                Admin
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary-600 to-primary-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Welcome to Tamrakar Complex
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Your trusted source for technology news, reviews, and insights in Nepal
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/search"
                className="inline-flex items-center justify-center px-8 py-3 bg-white text-primary-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors"
              >
                🔍 Search Articles
              </Link>
              <Link
                href="/category/reviews"
                className="inline-flex items-center justify-center px-8 py-3 bg-primary-800 text-white font-semibold rounded-lg hover:bg-primary-900 transition-colors"
              >
                ⭐ Read Reviews
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Featured Post */}
        {posts.length > 0 && (
          <section className="mb-12">
            <h2 className="text-3xl font-bold mb-6 text-gray-900">Featured Article</h2>
            <article className="bg-gradient-to-r from-primary-50 to-white rounded-xl border border-primary-200 overflow-hidden">
              <div className="p-8">
                <div className="flex items-center gap-2 text-sm text-primary-600 font-medium mb-3">
                  <span>{posts[0].category.name}</span>
                  <span>•</span>
                  <span>
                    {posts[0].publishedAt
                      ? new Date(posts[0].publishedAt).toLocaleDateString()
                      : ""}
                  </span>
                </div>
                <Link href={`/article/${posts[0].slug}`}>
                  <h3 className="text-2xl md:text-3xl font-bold text-gray-900 hover:text-primary-600 mb-4 transition-colors">
                    {posts[0].title}
                  </h3>
                </Link>
                <p className="text-gray-600 text-lg mb-4">{posts[0].excerpt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">By {posts[0].author.user.name}</span>
                  <Link
                    href={`/article/${posts[0].slug}`}
                    className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700"
                  >
                    Read More →
                  </Link>
                </div>
              </div>
            </article>
          </section>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Posts Feed */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6 text-gray-900">Latest News</h2>
            <div className="space-y-6">
              {posts.slice(1).map((post) => (
                <article
                  key={post.id}
                  className="bg-white rounded-xl shadow-sm border hover:shadow-md transition-shadow overflow-hidden"
                >
                  <div className="p-6">
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                      <span className="text-primary-600 font-medium">
                        {post.category.name}
                      </span>
                      <span>•</span>
                      <span>
                        {post.publishedAt
                          ? new Date(post.publishedAt).toLocaleDateString()
                          : "Draft"}
                      </span>
                    </div>
                    <Link href={`/article/${post.slug}`}>
                      <h3 className="text-xl font-bold text-gray-900 hover:text-primary-600 mb-2 transition-colors">
                        {post.title}
                      </h3>
                    </Link>
                    <p className="text-gray-600 mb-4">{post.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">
                        By {post.author.user.name}
                      </span>
                      <div className="flex gap-2">
                        {post.tags.slice(0, 3).map(({ tag }) => (
                          <span
                            key={tag.id}
                            className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full"
                          >
                            {tag.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <h3 className="font-bold text-lg mb-4">Categories</h3>
              <ul className="space-y-2">
                {categories.map((cat) => (
                  <li key={cat.id}>
                    <Link
                      href={`/category/${cat.slug}`}
                      className="text-gray-600 hover:text-primary-600"
                    >
                      {cat.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-primary-600 text-white rounded-lg shadow-sm p-6">
              <h3 className="font-bold text-lg mb-2">Newsletter</h3>
              <p className="text-primary-100 text-sm mb-4">
                Get the latest tech news delivered to your inbox
              </p>
              <NewsletterSignup />
            </div>
          </aside>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-bold">Tamrakar Complex</h3>
              <p className="text-gray-400 mt-1">
                © {new Date().getFullYear()} All rights reserved
              </p>
            </div>
            <div className="flex space-x-6">
              <Link href="/" className="text-gray-400 hover:text-white">
                Home
              </Link>
              <Link href="/admin" className="text-gray-400 hover:text-white">
                Admin
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
