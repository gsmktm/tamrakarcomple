import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/auth'

const prisma = new PrismaClient()

async function main() {
  // Create admin user
  const adminPassword = await hashPassword('admin123')
  const admin = await prisma.user.upsert({
    where: { email: 'admin@tamrakarcomplex.com' },
    update: {},
    create: {
      email: 'admin@tamrakarcomplex.com',
      name: 'Admin',
      password: adminPassword,
      role: 'admin',
    },
  })

  // Create categories
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { slug: 'technology' },
      update: {},
      create: {
        name: 'Technology',
        slug: 'technology',
        description: 'Latest tech news and updates',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'reviews' },
      update: {},
      create: {
        name: 'Reviews',
        slug: 'reviews',
        description: 'Product reviews and comparisons',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'how-to' },
      update: {},
      create: {
        name: 'How To',
        slug: 'how-to',
        description: 'Tutorials and guides',
      },
    }),
    prisma.category.upsert({
      where: { slug: 'news' },
      update: {},
      create: {
        name: 'News',
        slug: 'news',
        description: 'Breaking news and updates',
      },
    }),
  ])

  // Create tags
  const tags = await Promise.all([
    prisma.tag.upsert({
      where: { slug: 'smartphone' },
      update: {},
      create: { name: 'Smartphone', slug: 'smartphone' },
    }),
    prisma.tag.upsert({
      where: { slug: 'laptop' },
      update: {},
      create: { name: 'Laptop', slug: 'laptop' },
    }),
    prisma.tag.upsert({
      where: { slug: 'gadgets' },
      update: {},
      create: { name: 'Gadgets', slug: 'gadgets' },
    }),
    prisma.tag.upsert({
      where: { slug: 'software' },
      update: {},
      create: { name: 'Software', slug: 'software' },
    }),
    prisma.tag.upsert({
      where: { slug: 'nepal' },
      update: {},
      create: { name: 'Nepal', slug: 'nepal' },
    }),
  ])

  // Create admin user and author profile
  const adminUser = await prisma.user.upsert({
    where: { email: "admin@tamrakarcomplex.com" },
    update: {},
    create: {
      email: "admin@tamrakarcomplex.com",
      name: "Admin User",
      password: "$2b$10$rQZ8ZkGQJZKZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQZQ", // "admin123" hashed
    },
  });

  const author = await prisma.author.upsert({
    where: { userId: adminUser.id },
    update: {},
    create: {
      userId: adminUser.id,
      username: "admin",
    },
  });

  // Create posts
  const posts = await Promise.all([
    prisma.post.upsert({
      where: { slug: 'welcome-to-tamrakar-complex' },
      update: {},
      create: {
        title: 'Welcome to Tamrakar Complex',
        slug: 'welcome-to-tamrakar-complex',
        excerpt: 'Your trusted source for technology news and reviews in Nepal.',
        content: `<p>Welcome to <strong>Tamrakar Complex</strong>!</p>
<p>We are your premier destination for technology news, reviews, and insights in Nepal. Our team of experts brings you the latest updates on:</p>
<ul>
<li>Smartphones and gadgets</li>
<li>Laptops and computers</li>
<li>Software and apps</li>
<li>Tech industry news</li>
</ul>
<p>Stay tuned for comprehensive reviews, buying guides, and the latest tech news tailored for the Nepali market.</p>`,
        status: 'PUBLISHED',
        publishedAt: new Date(),
        authorId: author.id,
        categoryId: categories[3].id, // News
      },
    }),
    prisma.post.upsert({
      where: { slug: 'best-smartphones-2024' },
      update: {},
      create: {
        title: 'Best Smartphones to Buy in 2024',
        slug: 'best-smartphones-2024',
        excerpt: 'Our top picks for smartphones available in Nepal this year.',
        content: `<p>Looking for the best smartphone in Nepal? We've got you covered.</p>
<h2>Flagship Category</h2>
<p>The latest flagship phones offer incredible performance and cameras.</p>
<h2>Mid-Range Options</h2>
<p>Great value phones that don't break the bank.</p>
<h2>Budget Friendly</h2>
<p>Affordable options with good performance.</p>`,
        status: 'PUBLISHED',
        publishedAt: new Date(Date.now() - 86400000),
        authorId: author.id,
        categoryId: categories[1].id, // Reviews
      },
    }),
    prisma.post.upsert({
      where: { slug: 'how-to-choose-laptop' },
      update: {},
      create: {
        title: 'How to Choose the Right Laptop',
        slug: 'how-to-choose-laptop',
        excerpt: 'A comprehensive guide to selecting the perfect laptop for your needs.',
        content: `<p>Choosing a laptop can be overwhelming. Here's what to consider:</p>
<h2>Processor</h2>
<p>Intel or AMD? Which generation?</p>
<h2>RAM</h2>
<p>8GB minimum, 16GB recommended.</p>
<h2>Storage</h2>
<p>SSD vs HDD - why SSD is essential.</p>`,
        status: 'PUBLISHED',
        publishedAt: new Date(Date.now() - 172800000),
        authorId: author.id,
        categoryId: categories[2].id, // How To
      },
    }),
  ])

  // Add tags to posts
  await prisma.postTag.createMany({
    data: [
      { postId: posts[0].id, tagId: tags[4].id }, // Nepal tag
      { postId: posts[1].id, tagId: tags[0].id }, // Smartphone tag
      { postId: posts[1].id, tagId: tags[2].id }, // Gadgets tag
      { postId: posts[2].id, tagId: tags[1].id }, // Laptop tag
    ],
  })

  console.log('✅ Seed data created successfully!')
  console.log(`- Admin user: admin@tamrakarcomplex.com / admin123`)
  console.log(`- ${categories.length} categories`)
  console.log(`- ${tags.length} tags`)
  console.log(`- ${posts.length} posts`)
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
